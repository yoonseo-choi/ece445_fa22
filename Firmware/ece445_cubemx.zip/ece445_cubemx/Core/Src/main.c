/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <math.h>
#include "string.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// min and max positions for fingers
#define A_MAX 2450
#define A_MIN 1800
#define A_MID 2100 //min pulse val: 2055  mid pulse val: 2120

#define A_PULSE_MAX 1.82
#define A_PULSE_MIN 1.52

#define C_MAX 2275
#define C_MIN 1615
#define C_MID 1923 //min pulse val: 1930

#define C_PULSE_MAX 1.46
#define C_PULSE_MIN 1.13

#define B_MIN 1715
#define B_MAX 2435
#define B_MID 2070 //min pulse val: 2090

#define B_PULSE_MAX 1.65
#define B_PULSE_MIN 1.30

#define D_MIN 1795
#define D_MAX 2485
#define D_MID 2140 //min pulse val: 2180  mid pulse val: 2130

#define D_PULSE_MAX 1.61
#define D_PULSE_MIN 1.29

#define SERVOA_CENTER 1.65
#define SERVOB_CENTER 1.47
#define SERVOC_CENTER 1.3
#define SERVOD_CENTER 1.45

// number of servos
#define N 4

// servo pwm channels
#define SERVO_A TIM_CHANNEL_1
#define SERVO_B TIM_CHANNEL_2
#define SERVO_C TIM_CHANNEL_3
#define SERVO_D TIM_CHANNEL_4

#define PWM_START_PULSE 4695
//#define TEST_MODE 1

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

TIM_HandleTypeDef htim1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// init hand structure
Hand H;

float servo_update_hand (unsigned long servo_id, int direction) {
	uint16_t curr_pos;
	float pulse_change;

	if (servo_id == SERVO_A) {
		curr_pos = H.curr_A;
		pulse_change = (float)(curr_pos - A_MID)/ (A_MAX - A_MIN) * (A_PULSE_MAX - A_PULSE_MIN);
		pulse_change = (pulse_change < 0) ? (-1.0*pulse_change):pulse_change;

		// right
		if (direction) {
			if (curr_pos <= A_MID) {
				pulse_change = A_PULSE_MIN + pulse_change;
			}
			else {
				pulse_change = A_PULSE_MIN - pulse_change;
			}
		}
		// left
		else {
			if (curr_pos >= A_MID) {
				pulse_change = A_PULSE_MAX - pulse_change;
			}
			else {
				pulse_change = A_PULSE_MAX + pulse_change;
			}
		}
	}
	else if (servo_id == SERVO_C) {
		curr_pos = H.curr_C;
		pulse_change = (float)(curr_pos - C_MID)/ (C_MAX - C_MIN) * (C_PULSE_MAX - C_PULSE_MIN);
		pulse_change = (pulse_change < 0) ? (-1.0*pulse_change):pulse_change;

		/// right
		if (direction) {
			if (curr_pos <= C_MID) {
				pulse_change = C_PULSE_MIN + pulse_change;
			}
			else {
				pulse_change = C_PULSE_MIN - pulse_change;
			}
		}
		// left
		else {
			if (curr_pos >= C_MID) {
				pulse_change = C_PULSE_MAX - pulse_change;
			}
			else {
				pulse_change = C_PULSE_MAX + pulse_change;
			}
		}
	}
	else if (servo_id == SERVO_B) {
		curr_pos = H.curr_B;
		pulse_change = (float)(curr_pos - B_MID)/ (B_MAX - B_MIN) * (B_PULSE_MAX - B_PULSE_MIN);
		pulse_change = (pulse_change < 0) ? (-1.0*pulse_change):pulse_change;

		// right
		if (direction) {
			if (curr_pos <= B_MID) {
				pulse_change = B_PULSE_MIN + pulse_change;
			}
			else {
				pulse_change = B_PULSE_MIN - pulse_change;
			}
		}
		// left
		else {
			if (curr_pos >= B_MID) {
				pulse_change = B_PULSE_MAX - pulse_change;
			}
			else {
				pulse_change = B_PULSE_MAX + pulse_change;
			}
		}
	}
	else {
		curr_pos = H.curr_D;
		pulse_change = (float)(curr_pos - D_MID)/ (D_MAX - D_MIN) * (D_PULSE_MAX - D_PULSE_MIN);
		pulse_change = (pulse_change < 0) ? (-1.0*pulse_change):pulse_change;

		// right
		if (direction) {
			if (curr_pos <= D_MID) {
				pulse_change = D_PULSE_MIN + pulse_change;
			}
			else {
				pulse_change = D_PULSE_MIN - pulse_change;
			}
		}
		// left
		else {
			if (curr_pos >= D_MID) {
				pulse_change = D_PULSE_MAX - pulse_change;
			}
			else {
				pulse_change = D_PULSE_MAX + pulse_change;
			}
		}
	}
	return pulse_change;
}

float servo_set_pulse (unsigned long servo_id, float pulse) {

	uint32_t new_pulse =  (pulse * htim1.Init.Period) / 20;

	__HAL_TIM_SET_COMPARE (&htim1, servo_id, new_pulse);

	if (servo_id == SERVO_A) H.A = pulse;
	else if (servo_id == SERVO_B) H.B = pulse;
	else if (servo_id == SERVO_C) H.C = pulse;
	else H.D = pulse;

	return pulse;

}

float servo_left (unsigned long servo_id) {

	int drxn = 0;

	float pulse = servo_update_hand (servo_id, drxn);

	uint32_t new_pulse =  (pulse * htim1.Init.Period) / 20;

	__HAL_TIM_SET_COMPARE (&htim1, servo_id, new_pulse);

	if (servo_id == SERVO_A) H.A = pulse;
	else if (servo_id == SERVO_B) H.B = pulse;
	else if (servo_id == SERVO_C) H.C = pulse;
	else H.D = pulse;

//	HAL_Delay(100);

	return pulse;

}

float servo_right (unsigned long servo_id) {

	int drxn = 1;

	float pulse = servo_update_hand (servo_id, drxn);

	uint32_t new_pulse =  (pulse * htim1.Init.Period) / 20;

	__HAL_TIM_SET_COMPARE (&htim1, servo_id, new_pulse);

	if (servo_id == SERVO_A) H.A = pulse;
	else if (servo_id == SERVO_B) H.B = pulse;
	else if (servo_id == SERVO_C) H.C = pulse;
	else H.D = pulse;

//	HAL_Delay(100);

	return pulse;
}

float move_servo (uint16_t finger_id, char direction) {
	if (finger_id == 0) {
		// restrict finger A
		if (!H.is_index_collision_set) {
			H.is_index_collision_set = true;
			if (direction == '1') {
				 // restrict right (move servo right)
				return servo_left(SERVO_A);
			}
			else if (direction == '2') {
				// restrict left (move servo left)
				return servo_right(SERVO_A);
			}
			else {
				// restrict right
//				servo_left(SERVO_A);
				// restrict left
//				servo_right(SERVO_A);
			}
		}
		else {
			return servo_set_pulse(SERVO_A, H.A);
		}
	}
	else if (finger_id == 1) {
		// restrict finger B
		if (!H.is_middle_collision_set) {
			H.is_middle_collision_set = true;
			if (direction == '1') {
				 // restrict right (move servo right)
				return servo_left(SERVO_C);
			}
			else if (direction == '2') {
				// restrict left (move servo left)
				return servo_right(SERVO_C);
			}
			else {
				// restrict right
//				servo_left(SERVO_C);
				// restrict left
//				servo_right(SERVO_C);
			}
		}
		else {
			return servo_set_pulse(SERVO_C, H.C);
		}
	}
	else if (finger_id == 2) {
		// restrict finger C
		if (!H.is_ring_collision_set) {
			H.is_ring_collision_set = true;
			if (direction == '1') {
				 // restrict right (move servo right)
				return servo_left(SERVO_B);
			}
			else if (direction == '2') {
				// restrict left (move servo left)
				return servo_right(SERVO_B);
			}
			else {
				// restrict right
//				servo_left(SERVO_B);
				// restrict left
//				servo_right(SERVO_B);
			}
		}
		else {
			return servo_set_pulse(SERVO_B, H.B);
		}
	}
	else {
		// restrict finger E
		if (!H.is_pinky_collision_set) {
			H.is_pinky_collision_set = true;
			if (direction == '1') {
				 // restrict right (move servo right)
				return servo_left(SERVO_D);
			}
			else if (direction == '2') {
				// restrict left (move servo left)
				return servo_right(SERVO_D);
			}
			else {
				// restrict right
//				servo_left(SERVO_D);
				// restrict left
//				servo_right(SERVO_D);
			}
		}
		else {
			return servo_set_pulse(SERVO_D, H.D);
		}
	}
	return 0.0;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  // UART Transmit Data Packets
  char out_data_packet1 [20];
  char echo_in_packet [40];

  // ADC Potentiometer Readings
  uint16_t adc1 [N];

  // adc1[0]: pinky
  // adc1[1]: ring
  // adc1[2]: middle
  // adc1[3]: index

  char in_data_packet[N] = {'0','0','0','0'};
  float pulses[4] = {0.0, 0.0, 0.0, 0.0};

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_USART2_UART_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */

  // set original position of ALL servo motor
  servo_set_pulse(SERVO_A, SERVOA_CENTER);		// index finger (D7)
  servo_set_pulse(SERVO_B, SERVOB_CENTER);		// ring finger (D8)
  servo_set_pulse(SERVO_C, SERVOC_CENTER);		// middle finger (D2)
  servo_set_pulse(SERVO_D, SERVOD_CENTER);		// pinky ((th right side male pin down on CN10)


  // start the pwm
  HAL_TIM_PWM_Start(&htim1, SERVO_A);	// set servo motor to original middle position
  HAL_TIM_PWM_Start(&htim1, SERVO_B);
  HAL_TIM_PWM_Start(&htim1, SERVO_C);
  HAL_TIM_PWM_Start(&htim1, SERVO_D);
  
  H.is_index_collision_set = false;
  H.is_middle_collision_set = false;
  H.is_ring_collision_set = false;
  H.is_pinky_collision_set = false;

//  HAL_UART_Receive_DMA (&huart2, (uint8_t*)in_data_packet, strlen(in_data_packet));

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

//	  servo_set_pulse(SERVO_D, D_PULSE_MAX);
	  HAL_UART_Receive (&huart2, (uint8_t*)in_data_packet, strlen(in_data_packet), 20);

	  if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_0)) {
		  // input_algorithm:
		  HAL_ADC_Start_DMA (&hadc1, (uint32_t *)adc1, N);

		  // update A (index) pos
		  H.curr_A = adc1[3];
		  // update C (middle) pos
		  H.curr_C = adc1[2];
		  // update B (ring) pos
		  H.curr_B = adc1[1];
		  // update D (pinky) pos
		  H.curr_D = adc1[0];

		  // iterate for each finger
		  for (int i = 0; i < N; i++) {
			  // extract data from pc packet
			  uint16_t finger_id = i;
			  char collision_flag = in_data_packet[i];

			  // if there is a collision, move servo accordingly
			  if (collision_flag > '0' && collision_flag <= '3') {
				  pulses[i] = move_servo(finger_id, collision_flag);
			  }
			  else { // No collision so center servos
				  if (i == 0) {
					  H.is_index_collision_set = false;
					  servo_set_pulse(SERVO_A, SERVOA_CENTER);
				  }
				  else if (i == 1) {
					  H.is_middle_collision_set = false;
					  servo_set_pulse(SERVO_C, SERVOC_CENTER);
				  }
				  else if (i == 2) {
					  H.is_ring_collision_set = false;
					  servo_set_pulse(SERVO_B, SERVOB_CENTER);
				  }
				  else {
					  H.is_pinky_collision_set = false;
					  servo_set_pulse(SERVO_D, SERVOD_CENTER);
				  }
			  }
		  }

		  // output_algorithm:

		  // send potentiometer 1 readings on adc

//		  HAL_Delay(1000);

		  // read output channel
		  sprintf (out_data_packet1, "{%hu,%hu,%hu,%hu}\r\n", adc1[3], adc1[2], adc1[1], adc1[0]);

		  // read input data
		  sprintf (echo_in_packet, "[%hu,%hu,%hu,%hu]\r\n", in_data_packet[0], in_data_packet[1], in_data_packet[2], in_data_packet[3]); //%s,%s,%s,%s\n", res1, res2, res3, res4);

		  // send packets
		  HAL_UART_Transmit (&huart2, (uint8_t *)out_data_packet1, strlen(out_data_packet1), HAL_MAX_DELAY);
//		  HAL_UART_Transmit (&huart2, (uint8_t *)echo_in_packet, strlen(echo_in_packet), HAL_MAX_DELAY);

	  }
	  else {
		  // set original position of ALL servo motor
		  servo_set_pulse(SERVO_A, SERVOA_CENTER);		// index finger (D7)
		  servo_set_pulse(SERVO_B, SERVOB_CENTER);		// ring finger (D8)
		  servo_set_pulse(SERVO_C, SERVOC_CENTER);		// middle finger (D2)
		  servo_set_pulse(SERVO_D, SERVOD_CENTER);		// pinky ((th right side male pin down on CN10)
	  }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 144;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 4;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_15CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = 3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = 4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 23-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 62609-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 4695;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  __HAL_TIM_DISABLE_OCxPRELOAD(&htim1, TIM_CHANNEL_1);
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  __HAL_TIM_DISABLE_OCxPRELOAD(&htim1, TIM_CHANNEL_2);
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  __HAL_TIM_DISABLE_OCxPRELOAD(&htim1, TIM_CHANNEL_3);
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  __HAL_TIM_DISABLE_OCxPRELOAD(&htim1, TIM_CHANNEL_4);
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin : PC0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
